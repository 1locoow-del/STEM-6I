STEM 6 CLASS HUB UPDATE

This update keeps the existing photo gallery and adds:
- Message Wall (sender can choose anonymous or named; messages are visible to everyone)
- Digital Yearbook (shows recent gallery uploads without filenames)
- Time Capsule (letters are hidden in the page until their chosen date)
- Birthday Corner (month/day only)
- Class Bucket List

IMPORTANT SETUP BEFORE DEPLOYING
1. If you have NOT created the class_features table yet, open Supabase SQL Editor and run SUPABASE_FEATURES_SETUP.txt once.
2. If you already ran the previous class-features SQL successfully, do NOT run it again; the removed Question of the Day can simply remain unused in the database.
3. Deploy index.html from this ZIP to the existing Cloudflare Pages project: stem6-class-gallery. Keep index.html at the root.
4. Refresh the site.

The site uses only the Supabase publishable key already configured in index.html. Never add a service_role/secret key to the website.

PRIVACY NOTES
- The Message Wall is a shared public wall; it is not private messaging. Anonymous means the sender name is hidden on the wall, not that the database is private.
- Time Capsule entries are hidden by the website until the selected date, but the underlying table is readable to the public anon role. Do not put secrets, passwords, or sensitive personal information there.
- Birthday Corner asks for MM-DD only and stores a neutral placeholder year (2000); the interface displays month and day only.
- This starter version does not include editing, deleting, reporting, or moderation controls for messages. Bucket-list items can be checked off by anyone. The class/site owner should review posts and remove inappropriate content in Supabase.

If the features show a setup error, check that the SQL above ran successfully and that the table is named public.class_features.


NAVIGATION UPDATE
The website now uses a fixed bottom navigation bar with separate app-style pages. Home, Gallery, Messages, and Yearbook have direct tabs. Time Capsule, Birthday Corner, and Class Bucket List are opened from the More tab. Question of the Day has been removed.
